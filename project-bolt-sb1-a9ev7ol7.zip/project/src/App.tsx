import React, { useState } from 'react';
import Header from './components/Header';
import WordOfTheDay from './components/WordOfTheDay';
import Search from './components/Search';
import Bookmarks from './components/Bookmarks';

function App() {
  const [activeTab, setActiveTab] = useState<'word-of-day' | 'search' | 'bookmarks'>('word-of-day');

  const showWordOfDay = () => setActiveTab('word-of-day');
  const showSearch = () => setActiveTab('search');
  const showBookmarks = () => setActiveTab('bookmarks');

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header 
        onShowWordOfDay={showWordOfDay}
        onShowSearch={showSearch}
        onShowBookmarks={showBookmarks}
        activeTab={activeTab}
      />
      
      <main className="flex-grow">
        {activeTab === 'word-of-day' && <WordOfTheDay />}
        {activeTab === 'search' && <Search />}
        {activeTab === 'bookmarks' && <Bookmarks />}
      </main>
      
      <footer className="py-4 text-center text-sm text-gray-500 dark:text-gray-400">
        <p>© {new Date().getFullYear()} WordWise – Expand your vocabulary every day</p>
      </footer>
    </div>
  );
}

export default App;