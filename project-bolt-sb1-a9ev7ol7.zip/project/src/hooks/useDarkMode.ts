import { useState, useEffect } from 'react';
import { saveToLocalStorage, getFromLocalStorage } from '../utils/localStorage';

const COLOR_SCHEME_KEY = 'wordwise-color-scheme';

export function useDarkMode() {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    // Check localStorage first
    const savedMode = getFromLocalStorage<string | null>(COLOR_SCHEME_KEY, null);
    
    if (savedMode !== null) {
      return savedMode === 'dark';
    }
    
    // Check system preference if no localStorage value
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    const root = window.document.documentElement;
    
    if (isDarkMode) {
      root.classList.add('dark');
      saveToLocalStorage(COLOR_SCHEME_KEY, 'dark');
    } else {
      root.classList.remove('dark');
      saveToLocalStorage(COLOR_SCHEME_KEY, 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  return { isDarkMode, toggleDarkMode };
}