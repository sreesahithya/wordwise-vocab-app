import { useState, useEffect } from 'react';
import { saveToLocalStorage, getFromLocalStorage } from '../utils/localStorage';
import { getTodayKey, isSameDay } from '../utils/dateUtils';

const STREAK_KEY = 'wordwise-streak';
const LAST_VISIT_KEY = 'wordwise-last-visit';

interface StreakData {
  count: number;
  lastVisit: string;
}

export function useStreak() {
  const [streak, setStreak] = useState<number>(() => {
    const data = getFromLocalStorage<StreakData>(STREAK_KEY, { count: 0, lastVisit: '' });
    return data.count;
  });

  useEffect(() => {
    const today = new Date();
    const todayKey = getTodayKey();
    
    const storedData = getFromLocalStorage<StreakData>(STREAK_KEY, { count: 0, lastVisit: '' });
    
    if (!storedData.lastVisit) {
      // First visit
      const newData = { count: 1, lastVisit: todayKey };
      saveToLocalStorage(STREAK_KEY, newData);
      setStreak(1);
      return;
    }
    
    const lastVisitDate = new Date(storedData.lastVisit);
    
    if (isSameDay(today, lastVisitDate)) {
      // Already visited today, maintain streak
      setStreak(storedData.count);
    } else {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      
      if (isSameDay(yesterday, lastVisitDate)) {
        // Visited yesterday, increment streak
        const newStreak = storedData.count + 1;
        saveToLocalStorage(STREAK_KEY, { count: newStreak, lastVisit: todayKey });
        setStreak(newStreak);
      } else {
        // Streak broken, reset to 1
        saveToLocalStorage(STREAK_KEY, { count: 1, lastVisit: todayKey });
        setStreak(1);
      }
    }
  }, []);

  return { streak };
}