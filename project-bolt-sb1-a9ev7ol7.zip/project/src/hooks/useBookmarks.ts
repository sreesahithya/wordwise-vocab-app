import { useState, useEffect } from 'react';
import { Word } from '../types/Word';
import { saveToLocalStorage, getFromLocalStorage } from '../utils/localStorage';

const BOOKMARKS_KEY = 'wordwise-bookmarks';

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<Word[]>(() => 
    getFromLocalStorage<Word[]>(BOOKMARKS_KEY, [])
  );

  useEffect(() => {
    saveToLocalStorage(BOOKMARKS_KEY, bookmarks);
  }, [bookmarks]);

  const addBookmark = (word: Word) => {
    setBookmarks(prev => {
      // Check if word already exists in bookmarks
      if (!prev.some(bookmark => bookmark.word === word.word)) {
        return [...prev, word];
      }
      return prev;
    });
  };

  const removeBookmark = (wordToRemove: string) => {
    setBookmarks(prev => prev.filter(bookmark => bookmark.word !== wordToRemove));
  };

  const isBookmarked = (word: string): boolean => {
    return bookmarks.some(bookmark => bookmark.word === word);
  };

  return { bookmarks, addBookmark, removeBookmark, isBookmarked };
}