import { useState, useEffect } from 'react';
import { Word } from '../types/Word';
import { fetchWord, getRandomWord } from '../services/dictionaryApi';
import { saveToLocalStorage, getFromLocalStorage } from '../utils/localStorage';
import { getTodayKey } from '../utils/dateUtils';

const WORD_OF_DAY_KEY = 'wordwise-word-of-day';

export function useWordOfTheDay() {
  const [wordOfDay, setWordOfDay] = useState<Word | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchWordOfDay = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const todayKey = getTodayKey();
        const storedWord = getFromLocalStorage<{ date: string; word: Word } | null>(WORD_OF_DAY_KEY, null);
        
        if (storedWord && storedWord.date === todayKey) {
          // Use cached word for today
          setWordOfDay(storedWord.word);
        } else {
          // Fetch new word for today
          const newWord = await getRandomWord();
          saveToLocalStorage(WORD_OF_DAY_KEY, { date: todayKey, word: newWord });
          setWordOfDay(newWord);
        }
      } catch (err) {
        setError('Failed to fetch Word of the Day. Please try again later.');
        console.error('Error fetching word of the day:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchWordOfDay();
  }, []);

  return { wordOfDay, loading, error };
}