import { useState } from 'react';
import { Word } from '../types/Word';
import { fetchWord } from '../services/dictionaryApi';

export function useWordSearch() {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [searchResult, setSearchResult] = useState<Word | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const searchWord = async (word: string) => {
    if (!word.trim()) return;
    
    try {
      setLoading(true);
      setError(null);
      setSearchTerm(word);
      
      const result = await fetchWord(word.trim().toLowerCase());
      setSearchResult(result);
    } catch (err) {
      setSearchResult(null);
      setError(`Cannot find the word "${word}". Please check your spelling or try another word.`);
      console.error('Error searching word:', err);
    } finally {
      setLoading(false);
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setSearchResult(null);
    setError(null);
  };

  return { 
    searchTerm, 
    searchResult, 
    loading, 
    error, 
    searchWord,
    clearSearch
  };
}