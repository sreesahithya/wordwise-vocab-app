import React, { useState } from 'react';
import { Search as SearchIcon, X } from 'lucide-react';
import { useWordSearch } from '../hooks/useWordSearch';
import WordDetails from './WordDetails';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';

const Search: React.FC = () => {
  const { searchTerm, searchResult, loading, error, searchWord, clearSearch } = useWordSearch();
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    searchWord(inputValue);
  };

  const handleClear = () => {
    setInputValue('');
    clearSearch();
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-700 dark:text-gray-300">
          Search for a word
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Look up definitions, examples, and more
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-gray-400" />
          </div>
          
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="block w-full pl-10 pr-10 py-3 border border-gray-300 dark:border-gray-700 rounded-lg 
                      bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 
                      focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
                      transition-colors"
            placeholder="Type a word to search..."
            required
          />
          
          {inputValue && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute inset-y-0 right-12 flex items-center pr-3"
            >
              <X className="h-5 w-5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300" />
            </button>
          )}
          
          <button
            type="submit"
            className="absolute right-0 inset-y-0 px-4 text-white bg-blue-600 dark:bg-blue-700 
                     hover:bg-blue-700 dark:hover:bg-blue-800 rounded-r-lg transition-colors"
          >
            Search
          </button>
        </div>
      </form>
      
      {loading ? (
        <Loader />
      ) : error ? (
        <ErrorMessage message={error} />
      ) : searchResult ? (
        <WordDetails word={searchResult} />
      ) : null}
    </div>
  );
};

export default Search;