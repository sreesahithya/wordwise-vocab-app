import React from 'react';
import { useBookmarks } from '../hooks/useBookmarks';
import WordDetails from './WordDetails';
import { BookmarkX } from 'lucide-react';

const Bookmarks: React.FC = () => {
  const { bookmarks } = useBookmarks();

  if (bookmarks.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-6">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-gray-700 dark:text-gray-300">
            Your Bookmarks
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Save words to revisit later
          </p>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center">
          <BookmarkX className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-300 mb-2">No bookmarks yet</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Bookmark words you'd like to remember by clicking the bookmark icon
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-700 dark:text-gray-300">
          Your Bookmarks
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          {bookmarks.length} saved word{bookmarks.length !== 1 ? 's' : ''}
        </p>
      </div>
      
      <div className="space-y-6">
        {bookmarks.map((word) => (
          <WordDetails key={word.word} word={word} />
        ))}
      </div>
    </div>
  );
};

export default Bookmarks;