import React from 'react';
import { Bookmark, BookmarkCheck } from 'lucide-react';
import { Word, Meaning, Definition } from '../types/Word';
import AudioPlayer from './AudioPlayer';
import { useBookmarks } from '../hooks/useBookmarks';

interface WordDetailsProps {
  word: Word;
}

const WordDetails: React.FC<WordDetailsProps> = ({ word }) => {
  const { addBookmark, removeBookmark, isBookmarked } = useBookmarks();
  const bookmarked = isBookmarked(word.word);
  
  // Find first available audio
  const audioUrl = word.phonetics.find(p => p.audio)?.audio || '';
  
  // Get phonetic text
  const phoneticText = word.phonetics.find(p => p.text)?.text || '';
  
  const toggleBookmark = () => {
    if (bookmarked) {
      removeBookmark(word.word);
    } else {
      addBookmark(word);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-colors">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-3xl font-serif font-bold text-gray-900 dark:text-white">
            {word.word}
          </h2>
          <div className="flex items-center mt-1">
            {phoneticText && (
              <span className="text-gray-600 dark:text-gray-300 font-serif mr-2">
                {phoneticText}
              </span>
            )}
            {audioUrl && <AudioPlayer audioUrl={audioUrl} />}
          </div>
        </div>
        
        <button
          onClick={toggleBookmark}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label={bookmarked ? 'Remove from bookmarks' : 'Add to bookmarks'}
        >
          {bookmarked ? (
            <BookmarkCheck className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          ) : (
            <Bookmark className="w-6 h-6 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400" />
          )}
        </button>
      </div>
      
      <div className="space-y-6">
        {word.meanings.map((meaning, index) => (
          <MeaningSection key={index} meaning={meaning} />
        ))}
      </div>
      
      {word.sourceUrls && word.sourceUrls.length > 0 && (
        <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Source: <a href={word.sourceUrls[0]} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">{word.sourceUrls[0]}</a>
          </p>
        </div>
      )}
    </div>
  );
};

const MeaningSection: React.FC<{ meaning: Meaning }> = ({ meaning }) => {
  return (
    <div>
      <h3 className="text-lg font-medium text-purple-600 dark:text-purple-400 font-serif italic">
        {meaning.partOfSpeech}
      </h3>
      
      <div className="mt-2 space-y-3">
        {meaning.definitions.map((definition, index) => (
          <DefinitionItem key={index} definition={definition} index={index} />
        ))}
      </div>
      
      {meaning.synonyms.length > 0 && (
        <div className="mt-3">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Synonyms:</h4>
          <div className="flex flex-wrap gap-2 mt-1">
            {meaning.synonyms.map((synonym, index) => (
              <span 
                key={index}
                className="px-2 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 text-xs rounded-full"
              >
                {synonym}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const DefinitionItem: React.FC<{ definition: Definition; index: number }> = ({ definition, index }) => {
  return (
    <div>
      <p className="text-gray-800 dark:text-gray-200">
        <span className="font-medium mr-2">{index + 1}.</span>
        {definition.definition}
      </p>
      
      {definition.example && (
        <p className="mt-1 text-gray-600 dark:text-gray-400 text-sm pl-6 border-l-2 border-gray-200 dark:border-gray-700">
          "{definition.example}"
        </p>
      )}
    </div>
  );
};

export default WordDetails;