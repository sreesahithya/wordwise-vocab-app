import React, { useState } from 'react';
import { Book, Bookmark, Search as SearchIcon } from 'lucide-react';
import DarkModeToggle from './DarkModeToggle';
import StreakTracker from './StreakTracker';

interface HeaderProps {
  onShowBookmarks: () => void;
  onShowSearch: () => void;
  onShowWordOfDay: () => void;
  activeTab: 'word-of-day' | 'search' | 'bookmarks';
}

const Header: React.FC<HeaderProps> = ({
  onShowBookmarks,
  onShowSearch,
  onShowWordOfDay,
  activeTab
}) => {
  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-10 transition-colors">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center">
            <Book className="w-7 h-7 text-blue-600 dark:text-blue-400 mr-2" />
            <h1 
              className="text-xl font-bold text-gray-800 dark:text-white cursor-pointer"
              onClick={onShowWordOfDay}
            >
              WordWise
            </h1>
            <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">
              Daily Vocabulary Booster
            </span>
          </div>
          
          <div className="flex items-center justify-between sm:justify-end gap-2 sm:gap-4">
            <StreakTracker />
            
            <div className="flex items-center border-l border-gray-200 dark:border-gray-700 pl-2 sm:pl-4">
              <DarkModeToggle />
            </div>
          </div>
        </div>
        
        <nav className="flex mt-4 border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={onShowWordOfDay}
            className={`py-2 px-4 font-medium text-sm transition-colors ${
              activeTab === 'word-of-day'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Word of the Day
          </button>
          
          <button
            onClick={onShowSearch}
            className={`py-2 px-4 font-medium text-sm transition-colors flex items-center ${
              activeTab === 'search'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <SearchIcon className="w-4 h-4 mr-1" />
            Search
          </button>
          
          <button
            onClick={onShowBookmarks}
            className={`py-2 px-4 font-medium text-sm transition-colors flex items-center ${
              activeTab === 'bookmarks'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <Bookmark className="w-4 h-4 mr-1" />
            Bookmarks
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;