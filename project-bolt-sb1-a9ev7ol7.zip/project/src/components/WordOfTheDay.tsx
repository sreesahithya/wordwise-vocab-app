import React from 'react';
import { useWordOfTheDay } from '../hooks/useWordOfTheDay';
import WordDetails from './WordDetails';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';
import { formatDate } from '../utils/dateUtils';

const WordOfTheDay: React.FC = () => {
  const { wordOfDay, loading, error } = useWordOfTheDay();
  const today = new Date();

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-700 dark:text-gray-300">
          Word of the Day
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          {formatDate(today)}
        </p>
      </div>
      
      {loading ? (
        <Loader />
      ) : error ? (
        <ErrorMessage message={error} />
      ) : wordOfDay ? (
        <WordDetails word={wordOfDay} />
      ) : null}
    </div>
  );
};

export default WordOfTheDay;