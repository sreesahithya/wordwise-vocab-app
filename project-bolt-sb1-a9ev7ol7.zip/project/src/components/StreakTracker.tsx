import React from 'react';
import { Flame } from 'lucide-react';
import { useStreak } from '../hooks/useStreak';

const StreakTracker: React.FC = () => {
  const { streak } = useStreak();

  return (
    <div className="flex items-center gap-1 text-sm font-medium">
      <Flame className="w-5 h-5 text-orange-500" />
      <span className="text-gray-700 dark:text-gray-300">
        {streak} day{streak !== 1 ? 's' : ''} streak
      </span>
    </div>
  );
};

export default StreakTracker;