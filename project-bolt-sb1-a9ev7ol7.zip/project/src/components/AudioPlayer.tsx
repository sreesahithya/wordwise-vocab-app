import React, { useState, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

interface AudioPlayerProps {
  audioUrl: string;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ audioUrl }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const togglePlay = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    
    setIsPlaying(!isPlaying);
  };

  const onEnded = () => {
    setIsPlaying(false);
  };

  return (
    <div className="inline-flex items-center">
      <button
        onClick={togglePlay}
        className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 dark:bg-blue-900 dark:hover:bg-blue-800 transition-colors"
        aria-label={isPlaying ? 'Pause pronunciation' : 'Play pronunciation'}
      >
        {isPlaying ? (
          <VolumeX className="w-5 h-5 text-blue-600 dark:text-blue-400" />
        ) : (
          <Volume2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
        )}
      </button>
      <audio 
        ref={audioRef} 
        src={audioUrl} 
        onEnded={onEnded}
        className="hidden"
      />
    </div>
  );
};

export default AudioPlayer;