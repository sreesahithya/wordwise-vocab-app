const API_BASE_URL = 'https://api.dictionaryapi.dev/api/v2/entries/en';

export const fetchWord = async (word: string): Promise<any> => {
  try {
    const response = await fetch(`${API_BASE_URL}/${word}`);
    
    if (!response.ok) {
      throw new Error(`Error: ${response.status} - ${response.statusText}`);
    }
    
    const data = await response.json();
    return data[0];
  } catch (error) {
    throw error;
  }
};

export const getRandomWord = async (): Promise<any> => {
  // List of common English words for random selection
  const commonWords = [
    'serendipity', 'ephemeral', 'mellifluous', 'surreptitious', 'pernicious',
    'sagacious', 'eloquent', 'resilient', 'benevolent', 'meticulous',
    'cognizant', 'ubiquitous', 'quintessential', 'paradigm', 'esoteric',
    'insidious', 'clandestine', 'tenacious', 'vociferous', 'pragmatic'
  ];
  
  const randomIndex = Math.floor(Math.random() * commonWords.length);
  return fetchWord(commonWords[randomIndex]);
};